# RestaurantReservation(음식점 예약 관리 시스템)
참고한 사이트: [캐치테이블](https://app.catchtable.co.kr)<br>
---
류성찬: [AWS Ubuntu 주소](http://13.209.121.223:8080/RestaurantReservation/)<br>
---
## 개발자: 류성찬, 박재형, 박재호, 윤성렬, 정민기
---
## 개발환경
* ### 운영체제: Windows 10
* ### IDE: Eclipse 2021-12
* ### JDK: 11.0.13v
* ### Server: Tomcat9.0v
* ### DataBase: Oracle v10c
* ### Spring: 5.3.3
* ### Bootstrap5
* ### Cowork Tool: GitHub
---
## 데이터 관계도
<img src="https://user-images.githubusercontent.com/37442691/173721592-9cd3d06e-09a7-4bb2-b55e-d1a78a1e02de.jpg">

## 화면 관계도
<img src="https://user-images.githubusercontent.com/37442691/173727851-1acf966f-302c-4716-a916-70c44ada454e.png">
